<template>
  <Chart />
</template>

<script setup>
import Chart from '../components/Chart.vue'
</script>

<style>

</style>
